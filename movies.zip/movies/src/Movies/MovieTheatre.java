package Movies;

public class MovieTheatre {
    String movie1 = "Spiderman";
    String movie2 = "Avengers";
    String movie3 = "Life of PI";

    String theaterName = "Big Picture";

public MovieTheatre() {

}

    public String getMovie1() {
        return movie1;
    }
    public String getMovie2() {
        return movie2;
    }
    public String getMovie3() {
        return movie3;
    }
    public String getTheaterName() {
        return theaterName;
    }

}
